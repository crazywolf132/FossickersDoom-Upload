<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Subscriptions extends MY_Controller
{

    function __construct()
    {
        parent::__construct();
        $access = FALSE;
        if ($this->client) {
            redirect('csubscriptions');
        } elseif ($this->user) {
            foreach ($this->view_data['menu'] as $key => $value) {
                if ($value->link == "subscriptions") {
                    $access = TRUE;
                }
            }
            if (!$access) {
                redirect('login');
            }
        } else {
            redirect('login');
        }
        $this->view_data['submenu'] = array(
            $this->lang->line('application_all') => 'subscriptions',
            $this->lang->line('application_Active') => 'subscriptions/filter/active',
            $this->lang->line('application_Inactive') => 'subscriptions/filter/inactive',
        );

    }

    function index()
    {
        $this->view_data['subscriptions'] = Subscription::all();
        $this->content_view = 'subscriptions/all';
    }

    function filter($condition = FALSE)
    {
        switch ($condition) {
            case 'active':
                $this->view_data['subscriptions'] = Subscription::find('all', array('conditions' => array('status = ?', 'Active')));
                break;
            case 'inactive':
                $this->view_data['subscriptions'] = Subscription::find('all', array('conditions' => array('status = ?', 'Inactive')));
                break;
            default:
                $this->view_data['subscriptions'] = Subscription::all();
                break;
        }

        $this->content_view = 'subscriptions/all';
    }

    function create()
    {
        if ($_POST) {
            unset($_POST['send']);
            unset($_POST['_wysihtml5_mode']);
            /*$next_payment = human_to_unix($_POST['issue_date'].' 00:00');
            $next_payment = strtotime($_POST['frequency'], $next_payment);

            $_POST['next_payment'] = date("Y-m-d", $next_payment);*/
            $_POST['next_payment'] = $_POST['issue_date'];
            $subscription = Subscription::create($_POST);
            $new_subscription_reference = $_POST['reference'] + 1;
            $subscription_reference = Setting::first();
            $subscription_reference->update_attributes(array('subscription_reference' => $new_subscription_reference));
            if (!$subscription) {
                $this->session->set_flashdata('message', 'error:' . $this->lang->line('messages_create_subscription_error'));
            } else {
                $this->session->set_flashdata('message', 'success:' . $this->lang->line('messages_create_subscription_success'));
            }
            redirect('subscriptions');
        } else {
            $this->view_data['next_reference'] = Subscription::last();
            $this->view_data['companies'] = Company::find('all', array('conditions' => array('inactive=?', '0')));
            $this->theme_view = 'modal';
            $this->view_data['title'] = $this->lang->line('application_create_subscription');
            $this->view_data['form_action'] = 'subscriptions/create';
            $this->content_view = 'subscriptions/_subscription';
        }
    }

    function update($id = FALSE, $getview = FALSE)
    {
        if ($_POST) {
            unset($_POST['send']);
            unset($_POST['_wysihtml5_mode']);
            $id = $_POST['id'];
            $subscription = Subscription::find($id);
            if ($_POST['issue_date'] != $subscription->issue_date) {
                $_POST['next_payment'] = $_POST['issue_date'];
            }

            $view = FALSE;
            if (isset($_POST['view'])) {
                $view = $_POST['view'];
            }
            unset($_POST['view']);
            if ($_POST['status'] == "Paid") {
                $_POST['paid_date'] = date('Y-m-d', time());
            }

            $subscription->update_attributes($_POST);
            if (!$subscription) {
                $this->session->set_flashdata('message', 'error:' . $this->lang->line('messages_save_subscription_error'));
            } else {
                $this->session->set_flashdata('message', 'success:' . $this->lang->line('messages_save_subscription_success'));
            }
            if ($view == 'true') {
                redirect('subscriptions/view/' . $id);
            } else {
                redirect('subscriptions');
            }

        } else {
            $this->view_data['subscription'] = Subscription::find($id);
            $this->view_data['companies'] = Company::find('all', array('conditions' => array('inactive=?', '0')));
            if ($getview == "view") {
                $this->view_data['view'] = "true";
            }
            $this->theme_view = 'modal';
            $this->view_data['title'] = $this->lang->line('application_edit_subscription');
            $this->view_data['form_action'] = 'subscriptions/update';
            $this->content_view = 'subscriptions/_subscription';
        }
    }

    function view($id = FALSE)
    {
        $this->view_data['submenu'] = array(
            $this->lang->line('application_back') => 'subscriptions',
        );
        $this->view_data['subscription'] = Subscription::find($id);
        $this->view_data['items'] = SubscriptionHasItem::find('all', array('conditions' => array('subscription_id=?', $id)));

        $datediff = strtotime($this->view_data['subscription']->end_date) - strtotime($this->view_data['subscription']->issue_date);
        $timespan = floor($datediff / (60 * 60 * 24));
        switch ($this->view_data['subscription']->frequency) {
            case '+7 day':
                $this->view_data['run_time'] = round($timespan / 7);
                $this->view_data['p3'] = "1";
                $this->view_data['t3'] = "W";
                break;
            case '+14 day':
                $this->view_data['run_time'] = round($timespan / 14);
                $this->view_data['p3'] = "2";
                $this->view_data['t3'] = "W";
                break;
            case '+1 month':
                $this->view_data['run_time'] = round($timespan / 30);
                $this->view_data['p3'] = "1";
                $this->view_data['t3'] = "M";
                break;
            case '+3 month':
                $this->view_data['run_time'] = round($timespan / 90);
                $this->view_data['p3'] = "3";
                $this->view_data['t3'] = "M";
                break;
            case '+6 month':
                $this->view_data['run_time'] = round($timespan / 182);
                $this->view_data['p3'] = "6";
                $this->view_data['t3'] = "M";
                break;
            case '+1 year':
                $this->view_data['run_time'] = round($timespan / 365);
                $this->view_data['p3'] = "1";
                $this->view_data['t3'] = "Y";
                break;
        }
        $this->content_view = 'subscriptions/view';
    }

    function create_invoice($id = FALSE)
    {
        $subscription = Subscription::find($id);
        $invoice = Invoice::last();
        $invoice_reference = Setting::first();
        if ($subscription) {
            $_POST['subscription_id'] = $subscription->id;
            $_POST['company_id'] = $subscription->company_id;
            if ($subscription->subscribed != 0) {
                $_POST['status'] = "Paid";
            } else {
                $_POST['status'] = "Open";
            }
            $_POST['currency'] = $subscription->currency;
            $_POST['issue_date'] = $subscription->next_payment;
            $_POST['due_date'] = date('Y-m-d', strtotime('+3 day', strtotime($subscription->next_payment)));
            $_POST['currency'] = $subscription->currency;
            $_POST['terms'] = $subscription->terms;
            $_POST['discount'] = $subscription->discount;
            $_POST['reference'] = $invoice_reference->invoice_reference;
            $invoice = Invoice::create($_POST);
            $invoiceid = Invoice::last();
            $items = SubscriptionHasItem::find('all', array('conditions' => array('subscription_id=?', $id)));
            foreach ($items as $value):
                $itemvalues = array(
                    'invoice_id' => $invoiceid->id,
                    'item_id' => $value->item_id,
                    'amount' => $value->amount,
                    'description' => $value->description,
                    'value' => $value->value,
                    'name' => $value->name,
                    'type' => $value->type,
                );
                InvoiceHasItem::create($itemvalues);
            endforeach;
            $invoice_reference->update_attributes(array('invoice_reference' => $invoice_reference->invoice_reference + 1));
            if (!$invoice) {
                $this->session->set_flashdata('message', 'error:' . $this->lang->line('messages_create_invoice_error'));
            } else {
                $subscription->next_payment = date('Y-m-d', strtotime($subscription->frequency, strtotime($subscription->next_payment)));
                $subscription->save();
                $this->session->set_flashdata('message', 'success:' . $this->lang->line('messages_create_invoice_success'));
            }
            redirect('subscriptions/view/' . $id);
        }
    }

    function delete($id = FALSE)
    {
        $subscription = Subscription::find($id);
        $subscription->delete();
        $this->content_view = 'subscriptions/all';
        if (!$subscription) {
            $this->session->set_flashdata('message', 'error:' . $this->lang->line('messages_delete_subscription_error'));
        } else {
            $this->session->set_flashdata('message', 'success:' . $this->lang->line('messages_delete_subscription_success'));
        }
        redirect('subscriptions');
    }

    function sendsubscription($id = FALSE)
    {
        $this->load->helper(array('dompdf', 'file'));
        $this->load->library('parser');

        $data["subscription"] = Subscription::find($id);
        $data['items'] = SubscriptionHasItem::find('all', array('conditions' => array('subscription_id=?', $id)));
        $data["core_settings"] = Setting::first();

        $issue_date = date($data["core_settings"]->date_format, human_to_unix($data["subscription"]->issue_date . ' 00:00:00'));
        //Set parse values
        $parse_data = array(
            'client_contact' => $data["subscription"]->company->client->firstname . ' ' . $data["subscription"]->company->client->lastname,
            'issue_date' => $issue_date,
            'subscription_id' => $data["subscription"]->reference,
            'client_link' => $data["core_settings"]->domain,
            'company' => $data["core_settings"]->company,
            'logo' => '<img src="' . base_url() . '' . $data["core_settings"]->logo . '" alt="' . $data["core_settings"]->company . '"/>',
            'invoice_logo' => '<img src="' . base_url() . '' . $data["core_settings"]->invoice_logo . '" alt="' . $data["core_settings"]->company . '"/>'
        );
        //email
        $subject = $this->parser->parse_string($data["core_settings"]->subscription_mail_subject, $parse_data);
        $this->email->from($data["core_settings"]->email, $data["core_settings"]->company);
        $this->email->to($data["subscription"]->company->client->email);
        $this->email->subject($subject);

        $email_subscription = read_file('./application/views/blackline/templates/email_subscription.html');
        $message = $this->parser->parse_string($email_subscription, $parse_data);
        $this->email->message($message);
        if ($this->email->send()) {
            $this->session->set_flashdata('message', 'success:' . $this->lang->line('messages_send_subscription_success'));
            //$data["subscription"]->update_attributes(array('status' => 'Sent', 'sent_date' => date("Y-m-d")));
            log_message('error', 'Subscription #' . $data["subscription"]->reference . ' has been send to ' . $data["subscription"]->company->client->email);
        } else {
            $this->session->set_flashdata('message', 'error:' . $this->lang->line('messages_send_subscription_error'));
            log_message('error', 'ERROR: Subscription #' . $data["subscription"]->reference . ' has not been send to ' . $data["subscription"]->company->client->email . '. Please check your servers email settings.');
        }
        redirect('subscriptions/view/' . $id);
    }

    function item($id = FALSE)
    {
        if ($_POST) {
            unset($_POST['send']);
            $_POST = array_map('htmlspecialchars', $_POST);
            if ($_POST['name'] != "") {
                $_POST['name'] = $_POST['name'];
                $_POST['value'] = $_POST['value'];
                $_POST['type'] = $_POST['type'];
            } else {
                if ($_POST['item_id'] == "-") {
                    $this->session->set_flashdata('message', 'error:' . $this->lang->line('messages_add_item_error'));
                    redirect('subscriptions/view/' . $_POST['subscription_id']);

                } else {
                    $itemvalue = Item::find($_POST['item_id']);
                    $_POST['name'] = $itemvalue->name;
                    $_POST['type'] = $itemvalue->type;
                    $_POST['value'] = $itemvalue->value;
                }
            }

            $item = SubscriptionHasItem::create($_POST);
            if (!$item) {
                $this->session->set_flashdata('message', 'error:' . $this->lang->line('messages_add_item_error'));
            } else {
                $this->session->set_flashdata('message', 'success:' . $this->lang->line('messages_add_item_success'));
            }
            redirect('subscriptions/view/' . $_POST['subscription_id']);

        } else {
            $this->view_data['subscription'] = Subscription::find($id);
            $this->view_data['items'] = Item::find('all', array('conditions' => array('inactive=?', '0')));
            $this->theme_view = 'modal';
            $this->view_data['title'] = $this->lang->line('application_add_item');
            $this->view_data['form_action'] = 'subscriptions/item';
            $this->content_view = 'subscriptions/_item';
        }
    }

    function item_update($id = FALSE)
    {
        if ($_POST) {
            unset($_POST['send']);
            $_POST = array_map('htmlspecialchars', $_POST);
            $item = SubscriptionHasItem::find($_POST['id']);
            $item = $item->update_attributes($_POST);
            if (!$item) {
                $this->session->set_flashdata('message', 'error:' . $this->lang->line('messages_save_item_error'));
            } else {
                $this->session->set_flashdata('message', 'success:' . $this->lang->line('messages_save_item_success'));
            }
            redirect('subscriptions/view/' . $_POST['subscription_id']);

        } else {
            $this->view_data['subscription_has_items'] = SubscriptionHasItem::find($id);
            $this->theme_view = 'modal';
            $this->view_data['title'] = $this->lang->line('application_edit_item');
            $this->view_data['form_action'] = 'subscriptions/item_update';
            $this->content_view = 'subscriptions/_item';
        }
    }

    function item_delete($id = FALSE, $subscription_id = FALSE)
    {
        $item = SubscriptionHasItem::find($id);
        $item->delete();
        $this->content_view = 'subscriptions/view';
        if (!$item) {
            $this->session->set_flashdata('message', 'error:' . $this->lang->line('messages_delete_item_error'));
        } else {
            $this->session->set_flashdata('message', 'success:' . $this->lang->line('messages_delete_item_success'));
        }
        redirect('subscriptions/view/' . $subscription_id);
    }

}