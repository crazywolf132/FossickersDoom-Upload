<?php
$lang['event_invoice_overdue'] = 'Il pagamento della fattura  è {invoice_number} <span class="label label-important"> scaduti </span>';
$lang['event_project_overdue'] = 'Progetto {project_number} <span class="label label-important">termine raggiunto</span>';
$lang['event_subscription_new_invoice'] = '<span class="label label-warning">Fattura Nuovo</span> necessaria per la sottoscrizione {subscription_number}';