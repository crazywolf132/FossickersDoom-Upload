<?php
$lang['event_invoice_overdue'] = 'Zahlung für Rechnung {invoice_number} ist <span class="label label-important">überfällig</span>';
$lang['event_project_overdue'] = 'Projekt {project_number} hat die <span class="label label-important">Deadline</span> erreicht';
$lang['event_subscription_new_invoice'] = '<span class="label label-warning">Neue Rechnung</span> für Abonement {subscription_number} erstellen';

