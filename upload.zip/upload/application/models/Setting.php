<?php

class Setting extends ActiveRecord\Model
{
    static $table_name = 'core';
}
