<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
$config['useragent'] = 'Freelance Cockpit';
$config['mailtype'] = 'html';
$config['wordwrap'] = TRUE;