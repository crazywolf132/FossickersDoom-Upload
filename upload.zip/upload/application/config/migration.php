<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
$config['migration_enabled'] = FALSE;


/* End of file migration.php */
/* Location: ./application/config/migration.php */